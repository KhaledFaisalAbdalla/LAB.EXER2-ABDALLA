package com.example.labexer2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    EditText sch1, sch2, sch3, sch4, sch5, sch6, sch7, sch8;
    SharedPreferences sp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        sch1 = findViewById(R.id.sch_01);
        sch2 = findViewById(R.id.sch_02);
        sch3 = findViewById(R.id.sch_03);
        sch4 = findViewById(R.id.sch_04);
        sch5 = findViewById(R.id.sch_05);
        sch6 = findViewById(R.id.sch_06);
        sch7 = findViewById(R.id.sch_07);
        sch8 = findViewById(R.id.sch_08);

    }

    public void saveData(View v){
        sp = getSharedPreferences("data1", MODE_PRIVATE);
        SharedPreferences.Editor editor = sp.edit();

        String school1 = sch1.getText().toString();
        String school2 = sch2.getText().toString();
        String school3 = sch3.getText().toString();
        String school4 = sch4.getText().toString();
        String school5 = sch5.getText().toString();
        String school6 = sch6.getText().toString();
        String school7 = sch7.getText().toString();
        String school8 = sch8.getText().toString();
        editor.putString("school 1", school1);
        editor.putString("school 2", school2);
        editor.putString("school 3", school3);
        editor.putString("school 4", school4);
        editor.putString("school 5", school5);
        editor.putString("school 6", school6);
        editor.putString("school 7", school7);
        editor.putString("school 8", school8);

        editor.commit();
        Toast.makeText(this, "schools saved in data1.xml", Toast.LENGTH_LONG).show();
    }
    public void verify(View v) {
        Intent i = new Intent(this, Main2Activity.class);
        startActivity(i);
    }

}
