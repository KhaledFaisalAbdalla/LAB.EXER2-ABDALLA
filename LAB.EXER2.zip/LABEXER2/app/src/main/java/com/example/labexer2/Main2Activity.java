package com.example.labexer2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class Main2Activity extends AppCompatActivity {

    EditText sch1, sch2, sch3, sch4, sch5, sch6, sch7, sch8;
    SharedPreferences sp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        sch1 = findViewById(R.id.schoolfind);


    }

    public void verify2(View v) {
        sp = getSharedPreferences("data1", MODE_PRIVATE);
        String school1SP = sp.getString("school1", null);
        String school2SP = sp.getString("school2", null);
        String school3SP = sp.getString("school3", null);
        String school4SP = sp.getString("school4", null);
        String school5SP = sp.getString("school5", null);
        String school6SP = sp.getString("school6", null);
        String school7SP = sp.getString("school7", null);
        String school8SP = sp.getString("school8", null);
        String school1 = sch1.getText().toString();


        if (school1SP.equals(school1) || school2SP.equals(school1) || school3SP.equals(school1) || school4SP.equals(school1) || school5SP.equals(school1) || school6SP.equals(school1) || school7SP.equals(school1) || school8SP.equals(school1)) {
            Toast.makeText(this, "school is competing in UAAP ", Toast.LENGTH_LONG).show();
        } else {
            Toast.makeText(this, "school is not competing in UAAP", Toast.LENGTH_LONG).show();

        }


    }
}
